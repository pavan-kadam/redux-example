import React from 'react';
import {connect} from 'react-redux';
import {addTodo} from '../redux/action/TodoAction'

class  AddTodo extends React.Component {
    constructor(props) {
        super(props);
        this.text = React.createRef();
    }
    handleSubmit(e) {
        e.preventDefault();
        this.props.addTodo(this.text.current.value);
        this.text.current.value = "";
    }
    render() {
        return(
            <div>
                <form onSubmit={(event) => this.handleSubmit(event)}>
                    <input type="text" className="form-control" ref={this.text}/>
                    <input type="submit"/>
                </form>
                <h3>Click on the tab below to delete a list item</h3>
            </div>
        );
    }

}

export default connect (null, {addTodo})(AddTodo)
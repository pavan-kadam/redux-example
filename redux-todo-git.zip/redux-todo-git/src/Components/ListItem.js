import React from 'react';
import {connect} from 'react-redux';
import {deleteTodo} from '../redux/action/TodoAction';


class ListItem extends React.Component {
    deleteList() {
         this.props.deleteTodo(this.props.id);
    }
    
    render() {
        return(
           <ul>
               <li>
                   <span className="list-tab" onClick= {()=> this.deleteList()}>{this.props.text}</span>
                </li> 
           </ul>
        );
    }
}

export default connect (null, {deleteTodo})(ListItem)
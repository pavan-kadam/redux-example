import React from 'react';
import AddTodo from './Components/AddTodo';
import TodoList from './Components/TodoList';


export default class TodoApp extends React.Component {
  
    render() {
        return (
            <div  className="text-center">
                <h2>React - Redux TODO Example</h2>
                <AddTodo />
                <TodoList />
            </div>
        );
    }

}
import {ADD_TODO, DELETE_TODO} from './constants';

let counter = 2;

export function addTodo(_text) {
    let todos = {id : counter , text: _text};
    counter++;
    return {
        type: ADD_TODO,
        payload: todos
    }
}

export function deleteTodo(_id) {
    return {
        type: DELETE_TODO,
        payload: _id
    }
}

export default {addTodo, deleteTodo};
import store from '../store/store';
import constants  from '../action/constants';

let initialState = {
    todos : [{
        id: 1, text: 'My First List item'
    }]
}

function todoReducer(state = initialState, action) {
    switch(action.type) {

        case 'ADD_TODO' :
            state = {
                ...state,
                todos: [...state.todos, action.payload]
               
            } 
        break;
        case 'DELETE_TODO' :
                let _filtered = state.todos.filter((item) =>{
                    if(item.id !== action.payload) {
                        return item;
                    }
                })
            state = {
                ...state,
                todos: _filtered 
            }
            
        break;
    }
    return state;

}


export default todoReducer;